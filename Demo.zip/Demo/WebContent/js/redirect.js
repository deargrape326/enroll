/**
 * 界面跳转
 */
var path = getRootPath(); // 项目根目录

$(function() {
	$("#contact").click(function() {
		redirectTo("reg");
	})
})

function redirectTo(to){
	window.location.href = path + "/redirect/jsp?to=" + to;
}